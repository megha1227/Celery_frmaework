from celery import Celery
from flask import Flask

from celery.result import AsyncResult

app= Flask(__name__)
'''
import sys  
sys.path.append(pathToFolderContainingScripts)  
from scriptName import functionName #scriptName without .py extension  

or

https://www.geeksforgeeks.org/python-import-module-from-different-directory/
'''
'''
import sys

sys.path.insert(0,"/home/synerzip/PycharmProjects/Celery_fmwork/Flask-Celery-Docker-Redis/simple_worker")
from task import *


'''

# the above code can be uncommented when using delay,apply_async


'''
Executing tasks is done with apply_async(), and its shortcut: delay().

delay is simple and convenient, as it looks like calling a regular function:

Task.delay(arg1, arg2, kwarg1="x", kwarg2="y")
The same thing using apply_async is written like this:

Task.apply_async(args=[arg1, arg2], kwargs={"kwarg1": "x", "kwarg2": "y"})
You can also execute a task by name using send_task(), if you don’t have access to the task’s class:

Tip:

If the task isn’t registered in the current process you can use send_task() to call the task by name instead.
'''


# to use  send_task below code is imp
simple_app = Celery("task",broker="amqp://guest:guest@localhost:5672//",backend="rpc://")
# simple_app = Celery("task",broker="redis://localhost/0",backend="redis://localhost/0")
# the below line also worked with no change in the following code,better create a isntance on the folder level,since
# we r using script.function/modulename.fucntion name in the code

@app.route("/simple_start_the_task")
def invoke_the_method():
    app.logger.info("invking the task")
    # res = longtime_add.delay(10,2)
    # res = longtime_add.apply_async(kwargs={"x":10,"y":2})
    res = simple_app.send_task('task.longtime_add',kwargs={"x":10,"y":20})
    app.logger.info(f"reslut in backend is {res.backend}")
    return res.id

@app.route("/simple_task_status/<task_id>")
def get_the_Status(task_id):
    status = simple_app.AsyncResult(task_id,app = simple_app)
    # return "status of the task " + str(status.state)
    return "status of the task " + str(status.status)

@app.route("/simple_task_results/<task_id>")
def get_the_result(task_id):
    data = simple_app.AsyncResult(task_id,app = simple_app)
    # return "Result of the task " + str(data.result)
    return "Result of the task " + str(data.get())

if __name__ == "__main__":
    app.run(debug=True)