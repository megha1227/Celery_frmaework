from celery import Celery

import time
from celery.utils.log import get_task_logger


# https://stackoverflow.com/questions/6192265/send-log-messages-from-all-celery-tasks-to-a-single-file

app = Celery("task",broker = "redis://localhost/0",backend="redis://localhost/0")



logger = get_task_logger(__name__)

@app.task
def longtime_add(x,y):
    print("Got the request - starting the work")
    logger.info("Got the request - starting the work")
    time.sleep(30)
    # print("Work Finished Krishna")
    logger.info("Work Finished Krishna")
    return x+y