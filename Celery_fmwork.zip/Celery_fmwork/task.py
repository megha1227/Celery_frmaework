# extra:
# import os


# print(os.environ)
#
# for key,value in os.environ.items():
#     print(f"{key}....{value}")
#

import time
import redis
from celery import Celery

celery  = Celery(
    'task', #name of the que is task , has to be name of the module , to implement queue d
     backend = 'redis://localhost/0',#Keeping Results
# If you want to keep track of the tasks’ states, Celery needs to store or send the states somewhere. There are several built-in result backends to choose from: SQLAlchemy/Django ORM, MongoDB, Memcached, Redis, RPC (RabbitMQ/AMQP), and – or you can define your own.



    #Celery requires a solution to send and receive messages; usually this comes in the form of a separate service called a message broker.

# The second argument is the broker keyword argument, specifying the URL of the message broker you want to use.
    broker  = 'redis://localhost/0'
)

@celery.task
def background(n):

    """Function that returns the given string along with Hello and simulates the delay"""

    delay = 30
    print("Task runing")
    print(f"Simulating a delay of {delay} seconds ")

    time.sleep(delay)

    print("Task complete")

    _ = "HEllo "+str(n)
    return _


'''

#from task import *
background(10)
.
.
HEllo 10


its not running in back ground even though i ahve annotated with "@celery.task"


in order to run in the background u need to add ".delay" to that fucntion eg:
background.delay(10)
'''
